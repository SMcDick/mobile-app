/**
 * Created by nidhitandon on 10/05/17.
 */
import React, { Component } from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    View,
    Navigator,
    TextInput,
    TouchableOpacity,
    Dimensions,
    Platform,
    Keyboard,
    Modal,
    ActivityIndicator,
    Alert,
    NativeModules,
    Image,
    Animated,
    Easing,
    KeyboardAvoidingView,
    ScrollView
} from 'react-native';

import * as Animatable from 'react-native-animatable';
import Stripe from 'react-native-stripe-api'
const screenWidth=Dimensions.get('window').width;
const screenHeight=Dimensions.get('window').height;
import NavigationBar from './scenesNavBar'
import Utility from './Utility'


export default class StripePayment extends Component{
    constructor(props){
        super(props)
        this.state={
            modalState:false
        }
    }

    makePayment(){
        const apiKey = 'sk_test_f9r3pMzD3PKIelSCGydyOO7Q';
        const client = new Stripe(apiKey);

        // Create a Stripe token with new card infos
        const token =  client.createToken('tok_visa' , '09', '18', '111').then((res)=> {
                //alert(JSON.stringify(res))
                Alert.alert(
                    "Error",
                    "Please check the credentials",
                    [
                        {
                            text:"Ok",
                            onPress:() => { this.setState({modalState:false}) }
                        }
                    ]
                )})

            //alert(res.id)

        // Create a new customer and link your new card
        //const customer =  client.createCustomer(token.id, 'customer@email.com', '<Your user ID>', 'John', 'Doe');

        // Create charge, 1 USD
        //const charge =  client.createCharge(1 * 100, customer.id, 'Payment example','USD');
    }

    render(){
        return(
            <View style={{flex:1,backgroundColor:'rgb(233,234,238)'}} >
                <Modal
                    visible = {this.state.modalState}
                    transparent = {true}
                >
                    <TouchableOpacity
                        style={{flex:1,justifyContent:'center',backgroundColor:'rgba(20,20,20,0.6)'}}
                        activeOpacity={1}
                        onPress={() => this.setState({modalState:false})}
                    >
                        <ActivityIndicator size={"large"} color="black" />
                    </TouchableOpacity>
                </Modal>

                <View style={{height:Platform.OS=='ios'?75:60}}><NavigationBar navigator={this.props.navigator} route={this.props.route}/></View>

                <ScrollView contentContainerStyle={{flex:4}}>
                    <View style={{flex:1}}>
                        <Animatable.Image
                            source={require('../assets/credit-cards.png')}
                            style={styles.animatedSectionStyles}
                            animation="pulse" iterationCount= "infinite" duration={2000} delay={1000}
                        />
                    </View>

                    <KeyboardAvoidingView behavior={'height'} style={{flex:2,justifyContent:'space-around', alignItems:'center'}} >
                        <Text style={styles.sectionsHeadingStyles}>Card Number</Text>
                        <TextInput
                            autoCorrect={false}
                            autoCapitalize={"none"}
                            style={styles.textInputStyles}
                            placeholder="4242424242424242"
                            underlineColorAndroid={'white'}
                            returnKeyLabel = {"next"}
                            //value={"4242424242424242"}
                        />
                        <Text style={styles.sectionsHeadingStyles}>Card Holder Name</Text>
                        <TextInput
                            autoCorrect={false}
                            autoCapitalize={"none"}
                            style={styles.textInputStyles}
                            placeholder="john Doe"
                            underlineColorAndroid={'white'}
                            returnKeyLabel = {"next"}
                            //value={"john Doe"}
                        />
                        <Text style={styles.sectionsHeadingStyles}>email</Text>
                        <TextInput
                            autoCorrect={false}
                            autoCapitalize={"none"}
                            style={styles.textInputStyles}
                            placeholder="johndoe@gmail.com"
                            underlineColorAndroid={'white'}
                            returnKeyLabel = {"next"}
                            //value={"johndoe@gmail.com"}
                        />
                        <View style={{flex:1, flexDirection:'row'}}>
                            <View style={{flex:1}}>
                                <TextInput
                                    autoCorrect={false}
                                    autoCapitalize={"none"}
                                    style={styles.textInputStyles}
                                    placeholder="exp month"
                                    underlineColorAndroid={'white'}
                                    returnKeyLabel = {"next"}
                                    //value={"09"}
                                />
                            </View>

                            <View style={{flex:1}}>
                                <TextInput
                                    autoCorrect={false}
                                    autoCapitalize={"none"}
                                    style={styles.textInputStyles}
                                    placeholder="exp year"
                                    underlineColorAndroid={'white'}
                                    returnKeyLabel = {"next"}
                                    //value={"18"}
                                />
                            </View>

                            <View style={{flex:1}}>
                                <TextInput
                                    autoCorrect={false}
                                    autoCapitalize={"none"}
                                    style={styles.textInputStyles}
                                    placeholder="cvc"
                                    underlineColorAndroid={'white'}
                                    returnKeyLabel = {"next"}
                                    //value={"111"}
                                />
                            </View>
                        </View>
                    </KeyboardAvoidingView>

                    <View style={styles.buttonSectionLayoutStyles}>
                            <TouchableOpacity style={styles.modalButtonsStyles} onPress={()=>{
                                this.setState({modalState:true}, ()=>{this.makePayment()})
                                //this.props.navigator.pop()
                                }}>
                                <Text style={styles.modalButtonsTextStyles}>Make Payment</Text>
                            </TouchableOpacity>
                    </View>

                </ScrollView>

            </View>
        )
    }
}

const styles=StyleSheet.create({
    textInputStyles:{
        height:screenHeight/16,
        width:screenWidth,
        borderWidth:1,
        borderColor:'rgb(219,219,224)',
        marginBottom:8,
        backgroundColor:'white',
        borderRadius:5,
        padding:5,
        color:'rgb(153,153,153)',
    },
    modalButtonsStyles: {
       height:screenHeight/12,
        backgroundColor: 'rgb(233,234,238)',
        marginRight: screenWidth / 10,
        marginLeft: screenWidth / 10,
        borderRadius: 5,
        justifyContent: 'center',
        alignItems: 'center'
    },
    modalButtonsTextStyles:{
        color:'rgb(0,133,248)',
        alignSelf:'center',
        fontWeight:'300',
        fontSize:Utility.getFontSize()===50?50*0.4:23*0.6
    },
    dividerCellStyles:{
        borderWidth:0.3,
        backgroundColor:'rgb(233,234,238)'
    },
    animatedSectionStyles:{
        height:Utility.getFontSize()===50?240:100,
        width:Utility.getFontSize()===50?240:120,
        alignSelf:'center',
        marginTop:20
    },
    sectionsHeadingStyles:{
        color:'rgb(165,165,165)',
        alignSelf:'flex-start',
        fontSize:Utility.getFontSize()===50?50*0.4:23*0.6
    },
    buttonSectionLayoutStyles:{
        flex:1,
        backgroundColor:'white',
       padding:20
    },
})